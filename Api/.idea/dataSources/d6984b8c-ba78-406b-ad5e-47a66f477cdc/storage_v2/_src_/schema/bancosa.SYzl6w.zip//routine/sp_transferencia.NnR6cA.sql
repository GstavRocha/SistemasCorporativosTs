create
    definer = gustavo@localhost procedure sp_transferencia(IN sp_cod_transf_origem int, IN sp_cod_transf_destino int,
                                                           IN sp_valor_transferencia float)
begin
    insert into tb_movimentacao(cod_correntista,tipo_transacao,valor_movimentacao,data_operacao)
        values (sp_cod_transf_origem, 'TD',sp_valor_transferencia, NOW());
    IF  (@@ERROR_COUNT = 0 )
    then
        INSERT INTO tb_movimentacao(cod_correntista, tipo_transacao, valor_movimentacao, data_operacao)
        values (sp_cod_transf_destino,'TC',sp_valor_transferencia,NOW());
    end if;
end;

