create definer = gustavo@localhost trigger tii_movimentacao
    after insert
    on tb_movimentacao
    for each row
begin
        DECLARE codigo_correntista int;
        DECLARE valor float(10,2);
        DECLARE tipo_transacao char(2);

       select m.cod_correntista, m.valor_movimentacao, m.tipo_transacao into codigo_correntista, valor, tipo_transacao from tb_movimentacao as m where cod_correntista = new.cod_correntista;
        if tipo_transacao in ('TC', 'DP') then
            update tb_correntista set saldo_correntista= NEW.valor_movimentacao + valor where cod_correntista = new.cod_correntista;
        else
            update tb_correntista set saldo_correntista= new.valor_movimentacao + valor where cod_correntista = new.cod_correntista;
        end if;
    end;

