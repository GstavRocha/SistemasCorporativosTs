create
    definer = gustavo@localhost procedure sp_pagamento(IN sp_cod_correntista_pagamento int, IN sp_valor_pagamento float)
begin
    insert into tb_movimentacao(cod_correntista, tipo_transacao, valor_movimentacao, data_operacao)
        values (sp_cod_correntista_pagamento, 'PG', sp_valor_pagamento, now());
end;

