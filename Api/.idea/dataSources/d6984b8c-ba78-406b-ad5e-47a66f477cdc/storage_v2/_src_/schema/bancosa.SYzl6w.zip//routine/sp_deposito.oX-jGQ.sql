create
    definer = gustavo@localhost procedure sp_deposito(IN sp_cod_correntista int, IN sp_valor float)
begin
    insert into tb_movimentacao(cod_correntista, tipo_transacao, valor_movimentacao, data_operacao)
        values (sp_cod_correntista, 'DP',sp_valor, NOW());
end;

