create
    definer = gustavo@localhost procedure sp_extrato_correntista(IN sp_cod_correntista int, IN sp_data_inicial datetime,
                                                                 IN sp_data_final datetime)
begin
    select data_operacao, tipo_transacao,valor_movimentacao from vw_extratoCorrentista
        where cod_correntista=sp_cod_correntista
        and data_operacao between sp_data_inicial and sp_data_final
        order by data_operacao;
end;

