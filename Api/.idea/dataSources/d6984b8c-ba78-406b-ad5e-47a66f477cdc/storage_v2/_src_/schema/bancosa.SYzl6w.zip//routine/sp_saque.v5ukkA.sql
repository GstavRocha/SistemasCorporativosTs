create
    definer = gustavo@localhost procedure sp_saque(IN sp_cod_saque int, IN sp_valor_saque float)
begin
    insert into tb_movimentacao(cod_correntista, tipo_transacao, valor_movimentacao, data_operacao)
        values (sp_cod_saque,'SQ',sp_valor_saque, NOW());
end;

