create definer = gustavo@localhost view vw_extratoCorrentista as
select `bancosa`.`tb_correntista`.`cod_correntista`       AS `cod_correntista`,
       `bancosa`.`tb_correntista`.`nome_correntista`      AS `nome_correntista`,
       `bancosa`.`tb_movimentacao`.`data_operacao`        AS `data_operacao`,
       `bancosa`.`tb_movimentacao`.`tipo_transacao`       AS `tipo_transacao`,
       `bancosa`.`tb_movimentacao`.`valor_movimentacao`   AS `valor_movimentacao`,
       (case `bancosa`.`tb_movimentacao`.`tipo_transacao`
            when 'DP' then 'Deposito'
            when 'SQ' then 'Saque'
            when 'PG' then 'Pagamento'
            when 'TC' then 'Transferencia de crédito'
            when 'TD' then 'Transferencia de debito' end) AS `tipo_Operacao_Descricao`
from (`bancosa`.`tb_correntista` join `bancosa`.`tb_movimentacao`
      on ((`bancosa`.`tb_correntista`.`cod_correntista` = `bancosa`.`tb_movimentacao`.`cod_correntista`)));

